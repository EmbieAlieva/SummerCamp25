import { Injectable } from '@angular/core';
import { Incidence } from '../models/incidence';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class IncidencesPagination {
//   incidences: Incidence[] = [];
//   totalRegisters: number;
// }

@Injectable({providedIn: 'root'})
export class IncidencesService {

  private apiUrl = 'https://localhost:7231/api/Incidences';

  constructor(private http: HttpClient) {}

  getIncidences(page: number, pageSize: number): Observable<Incidence[]> {
    // Obtener todos y paginar en frontend
    return new Observable<Incidence[]>(observer => {
      this.http.get<Incidence[]>(this.apiUrl).subscribe(allData => {
        const start = (page - 1) * pageSize;
        const end = start + pageSize;
        observer.next(allData.slice(start, end));
        observer.complete();
      }, err => observer.error(err));
    });
  }

  getIncidenceById(id: number): Observable<Incidence> {
    return this.http.get<Incidence>(`${this.apiUrl}/${id}`);
  }

  addIncidence(incidence: Incidence): Observable<Incidence> {
    return this.http.post<Incidence>(`${this.apiUrl}`, incidence);
  }

  updateIncidence(id: number, incidence: Incidence): Observable<Incidence> {
    return this.http.put<Incidence>(`${this.apiUrl}/${id}`, incidence);
  }
  // updateIncident(id: number, incident: Incident): Observable<void> {
  //   return this.http.put<void>(`${this.apiUrl}/${id}`, incident);
  // }

  deleteIncidence(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getTotalRegisters(): Observable<number> {
    return new Observable<number>(observer => {
      this.http.get<Incidence[]>(this.apiUrl).subscribe(allData => {
        observer.next(allData.length);
        observer.complete();
      }, err => observer.error(err));
    });
  }
}
