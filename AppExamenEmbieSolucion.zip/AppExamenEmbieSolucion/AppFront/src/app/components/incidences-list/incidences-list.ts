import { Component } from '@angular/core';
import { Incidence } from '../../models/incidence';
import { Router } from '@angular/router';
import { IncidencesService } from '../../services/incidence';

@Component({
  selector: 'app-incidences-list',
  standalone: false,
  templateUrl: './incidences-list.html',
  styleUrl: './incidences-list.css'
})
export class IncidencesList {
  incidences: Incidence[] = [];
  allIncidences: Incidence[] = [];
  page = 1;
  pageSize = 10;
  totalRegisters = 0;
  totalPages = 1;
  filterName = '';
  filterDateFrom: string = '';
  filterDateTo: string = '';

  deleteIncidence(id: number) {
    if (confirm('¿Seguro que deseas eliminar esta incidencia?')) {
      this.incidenceService.deleteIncidence(id).subscribe(() => {
        this.loadAllIncidences();
      });
    }
  }

  constructor(private incidenceService: IncidencesService, private router: Router) {}

  ngOnInit(): void {
    this.loadAllIncidences();
  }

  loadAllIncidences() {
    this.incidenceService.getIncidences(1, 10000).subscribe(data => {
      this.allIncidences = data;
      this.applyFilters();
    });
  }

  applyFilters() {
    let filtered = this.allIncidences;
    if (this.filterName.trim()) {
      filtered = filtered.filter(i => i.nameClient && i.nameClient.toLowerCase().includes(this.filterName.trim().toLowerCase()));
    }
    if (this.filterDateFrom) {
      filtered = filtered.filter(i => {
        const dateOnly = i.reportedAt ? (i.reportedAt.split('T')[0].split(' ')[0]) : '';
        return dateOnly >= this.filterDateFrom;
      });
    }
    if (this.filterDateTo) {
      filtered = filtered.filter(i => {
        const dateOnly = i.reportedAt ? (i.reportedAt.split('T')[0].split(' ')[0]) : '';
        return dateOnly <= this.filterDateTo;
      });
    }
    this.totalRegisters = filtered.length;
    this.totalPages = Math.max(1, Math.ceil(this.totalRegisters / this.pageSize));
    if (this.page > this.totalPages) {
      this.page = this.totalPages;
    }
    const start = (this.page - 1) * this.pageSize;
    const end = start + this.pageSize;
    this.incidences = filtered.slice(start, end);
  }



  onFilterChange() {
    this.page = 1;
    this.applyFilters();
  }

  firstPage() {
    if (this.page !== 1) {
      this.page = 1;
      this.applyFilters();
    }
  }

  nextPage() {
    if (this.page < this.totalPages) {
      this.page++;
      this.applyFilters();
    }
  }

  previousPage() {
    if (this.page > 1) {
      this.page--;
      this.applyFilters();
    }
  }

  lastPage() {
    if (this.page !== this.totalPages) {
      this.page = this.totalPages;
      this.applyFilters();
    }
  }

  translateStatus(status: string): string {
    const translations: any = {
      Reported: 'Reportado',
      InProgress: 'En progreso',
      Resolved: 'Resuelto',
      Closed: 'Cerrado'
    };
    return translations[status] || status;
  }

  // Eliminadas funciones duplicadas y referencias a refresh

  viewDetail(id: number) {
    this.router.navigate(['/incidencia', id]);
  }
}
