﻿namespace AppExamenEmbieProyecto
{
    public class Class1
    {

    }
}
