using Microsoft.AspNetCore.Mvc;
using Dominio;
using DTOs;
using AppData;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace SistemaAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IncidencesController : ControllerBase
    {
        private readonly ContextDB _context;
        private readonly IMapper _mapper;

        public IncidencesController(ContextDB context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        // GET: api/Incidences
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IncidenciaDto>>> GetIncidences()
        {
            var incidences = await _context.Incidences.ToListAsync();
            return Ok(_mapper.Map<IEnumerable<IncidenciaDto>>(incidences));
        }

        // GET: api/Incidences/5
        [HttpGet("{id}")]
        public async Task<ActionResult<IncidenciaDto>> GetIncidence(int id)
        {
            var incidence = await _context.Incidences.FindAsync(id);
            if (incidence == null)
                return NotFound();
            return Ok(_mapper.Map<IncidenciaDto>(incidence));
        }

        // POST: api/Incidences
        [HttpPost]
        public async Task<ActionResult<IncidenciaDto>> PostIncidence(IncidenciaDto dto)
        {
            var incidence = new Incidence
            {
                NameClient = dto.NameClient,
                Description = dto.Description,
                ReportedAt = DateTime.TryParse(dto.ReportedAt, out var date) ? date : DateTime.Now,
                IsUrgent = dto.IsUrgent,
                Status = Enum.TryParse<IncidentStatus>(dto.Status, out var status) ? status : IncidentStatus.Reported
            };
            _context.Incidences.Add(incidence);
            await _context.SaveChangesAsync();
            var resultDto = _mapper.Map<IncidenciaDto>(incidence);
            return CreatedAtAction(nameof(GetIncidence), new { id = incidence.Id }, resultDto);
        }

        // PUT: api/Incidences/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutIncidence(int id, IncidenciaDto dto)
        {
            var incidence = await _context.Incidences.FindAsync(id);
            if (incidence == null)
                return NotFound();
            incidence.NameClient = dto.NameClient;
            incidence.Description = dto.Description;
            incidence.ReportedAt = DateTime.TryParse(dto.ReportedAt, out var date) ? date : incidence.ReportedAt;
            incidence.IsUrgent = dto.IsUrgent;
            incidence.Status = Enum.TryParse<IncidentStatus>(dto.Status, out var status) ? status : incidence.Status;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/Incidences/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteIncidence(int id)
        {
            var incidence = await _context.Incidences.FindAsync(id);
            if (incidence == null)
                return NotFound();
            _context.Incidences.Remove(incidence);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
